import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
import './style.css';
createRoot(document.getElementById('root')!).render(<App/>);
if('serviceWorker' in navigator && location.protocol==='https:')window.addEventListener('load',()=>{navigator.serviceWorker.register('./sw.js').then(()=>navigator.storage?.persist?.()).catch(()=>{})});
