import { Plan, planSchema } from './plans';
const database='planfolio-device-v1';
function open():Promise<IDBDatabase>{
 return new Promise((resolve,reject)=>{
  const r=indexedDB.open(database,1);
  r.onupgradeneeded=()=>r.result.createObjectStore('plans');
  r.onsuccess=()=>resolve(r.result);
  r.onerror=()=>reject(new Error('无法打开本机存储，请退出无痕模式或导出备份'));
  r.onblocked=()=>reject(new Error('本机数据库被旧页面占用，请关闭其他页面'));
 });
}
export async function readLocal():Promise<Plan|null>{
 const db=await open();
 try{
  return await new Promise<Plan|null>((resolve,reject)=>{
   const t=db.transaction('plans','readonly'),r=t.objectStore('plans').get('current');
   r.onsuccess=()=>{try{resolve(r.result?planSchema.parse(r.result):null)}catch{reject(new Error('本机数据校验失败，请恢复备份'))}};
   r.onerror=()=>reject(r.error);
  });
 }finally{db.close()}
}
export async function writeLocal(data:Plan){
 const valid=planSchema.parse(data),db=await open();
 try{
  await new Promise<void>((resolve,reject)=>{
   const t=db.transaction('plans','readwrite');
   t.objectStore('plans').put(valid,'current');
   t.oncomplete=()=>resolve();
   t.onerror=()=>reject(new Error('本机保存失败，存储空间可能不足，请导出备份'));
   t.onabort=()=>reject(new Error('本机保存中断，请导出备份'));
  });
 }finally{db.close()}
}
