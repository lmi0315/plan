import { z } from 'zod';
const date=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(s=>{const d=new Date(s+'T00:00:00Z');return !isNaN(+d)&&d.toISOString().slice(0,10)===s},'日期无效');
export const itemSchema=z.object({id:z.string().min(1).max(100),title:z.string().trim().min(1).max(200),space:z.enum(['personal','work']),kind:z.enum(['goal','month','week','project','task','milestone']),parent:z.string().max(100),start:date,end:date,status:z.enum(['todo','doing','done','blocked']),progress:z.number().int().min(0).max(100),priority:z.enum(['high','medium','low']),owner:z.string().max(80),notes:z.string().max(20000),sample:z.boolean().optional()}).refine(x=>x.end>=x.start,'结束日期不能早于开始日期');
export const planSchema=z.object({items:z.array(itemSchema).max(3000)}).superRefine((p,ctx)=>{
 const ids=new Set(p.items.map(x=>x.id));if(ids.size!==p.items.length)ctx.addIssue({code:'custom',message:'ID重复'});
 for(const item of p.items){if(item.parent&&!ids.has(item.parent))ctx.addIssue({code:'custom',message:'父计划不存在'});let cur=item;const visited=new Set<string>();while(cur.parent){if(visited.has(cur.id)){ctx.addIssue({code:'custom',message:'计划关联形成循环'});break}visited.add(cur.id);const parent=p.items.find(x=>x.id===cur.parent);if(!parent)break;if(parent.space!==item.space)ctx.addIssue({code:'custom',message:'不能跨空间关联'});cur=parent;}}
});
export type Item=z.infer<typeof itemSchema>;
export type Plan=z.infer<typeof planSchema>;
export const newId=()=>typeof crypto!=='undefined'&&typeof crypto.randomUUID==='function'?crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)+'-'+Math.random().toString(36).slice(2);
export const kinds:Record<Item['kind'],string>={goal:'年度目标',month:'月计划',week:'周计划',project:'系统项目',task:'项目任务',milestone:'里程碑'};
export const statuses:Record<Item['status'],string>={todo:'未开始',doing:'进行中',done:'已完成',blocked:'有阻塞'};
export const fmt=(d:Date)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
export const addDays=(s:string,n:number)=>{const d=new Date(s+'T12:00:00');d.setDate(d.getDate()+n);return fmt(d)};
export const days=(a:string,b:string)=>Math.round((Date.parse(b+'T00:00:00Z')-Date.parse(a+'T00:00:00Z'))/86400000);
export function seed():Plan{const y=new Date().getFullYear(),m=fmt(new Date()).slice(0,7),today=fmt(new Date()),end=addDays(today,20);const make=(id:string,title:string,space:Item['space'],kind:Item['kind'],parent:string,start:string,finish:string,progress:number,status:Item['status']='doing'):Item=>({id,title,space,kind,parent,start,end:finish,progress,status,priority:'medium',owner:'我',notes:'示例内容，可按实际情况修改；不代表真实项目进度。',sample:true});return {items:[
make('g1','建立稳定的运动与学习节奏','personal','goal','',`${y}-01-01`,`${y}-12-31`,42),
make('m1','本月：完成 12 次家庭训练','personal','month','g1',`${m}-01`,`${m}-${new Date(y,new Date().getMonth()+1,0).getDate()}`,33),
make('w1','本周：3 次基础力量训练','personal','week','m1',today,addDays(today,6),33),
make('g2','掌握 Web 系统开发基础','personal','goal','',`${y}-01-01`,`${y}-12-31`,25),
make('w2','动手理解 HTTP 请求与响应','personal','week','g2',today,addDays(today,3),0,'todo'),
make('p1','市场风险管理系统重构','work','project','',addDays(today,-10),addDays(today,60),28),
make('t1','POC 方案与评价标准确认','work','task','p1',addDays(today,-4),addDays(today,4),65),
make('t2','计量引擎与产品功能验证','work','task','p1',addDays(today,5),end,0,'todo'),
make('ms1','POC 评审完成','work','milestone','p1',end,end,0,'todo'),
make('p2','新金融工具减值系统（IFRS 9）','work','project','',addDays(today,-5),addDays(today,45),15),
make('t3','整理架构评审待确认事项','work','task','p2',today,addDays(today,5),20,'blocked'),
make('ms2','架构方案确认','work','milestone','p2',addDays(today,12),addDays(today,12),0,'todo')
]}}
export function progress(item:Item,items:Item[]):number{if(item.status==='done')return 100;const children=items.filter(x=>x.parent===item.id);return children.length?Math.round(children.reduce((a,x)=>a+progress(x,items),0)/children.length):item.progress;}
const esc=(s:string)=>s.replace(/\\/g,'\\\\').replace(/\r?\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');
export function toICS(items:Item[]){const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Planfolio//ZH','CALSCALE:GREGORIAN','METHOD:PUBLISH'];for(const x of items){lines.push('BEGIN:VEVENT',`UID:${x.id}@planfolio`,`DTSTAMP:${new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'')}`,`DTSTART;VALUE=DATE:${x.start.replace(/-/g,'')}`,`DTEND;VALUE=DATE:${addDays(x.end,1).replace(/-/g,'')}`,`SUMMARY:${esc(x.title)}`,`DESCRIPTION:${esc(x.notes)}`,`STATUS:${x.status==='done'?'CONFIRMED':'TENTATIVE'}`,'END:VEVENT')}lines.push('END:VCALENDAR');return lines.map(line=>{const parts:string[]=[];let part='',bytes=0;for(const ch of line){const size=new TextEncoder().encode(ch).length;if(bytes+size>73){parts.push(part);part=' ';bytes=1;}part+=ch;bytes+=size;}parts.push(part);return parts.join('\r\n')}).join('\r\n')+'\r\n'}
export function fromICS(text:string,space:Item['space']):Item[]{const blocks=text.replace(/\r?\n[ \t]/g,'').split('BEGIN:VEVENT').slice(1);if(blocks.length>500)throw new Error('一次最多导入 500 个事件');return blocks.map(block=>{if(/RRULE:|RECURRENCE-ID/.test(block))throw new Error('暂不支持重复日程，请先在日历中导出为单次事件');const get=(key:string)=>block.match(new RegExp('(?:^|\\n)'+key+'(?:;[^:\\r\\n]*)?:([^\\r\\n]*)'))?.[1]||'';const un=(s:string)=>s.replace(/\\([nN,;\\])/g,(_,c)=>c==='n'||c==='N'?'\n':c);const date=(s:string)=>/^\d{8}/.test(s)?`${s.slice(0,4)}-${s.slice(4,6)}-${s.slice(6,8)}`:'';const start=date(get('DTSTART'));const endRaw=get('DTEND');const end=endRaw?addDays(date(endRaw),endRaw.length===8?-1:0):start;return {id:'ics-'+(get('UID')||newId()).slice(0,90),title:un(get('SUMMARY'))||'导入的日程',space,kind:space==='work'?'task':'week',parent:'',start,end:end<start?start:end,status:'todo',progress:0,priority:'medium',owner:'我',notes:un(get('DESCRIPTION'))}})}
