import type {Item} from './plans.ts';
import {fmt,addDays,days} from './plans.ts';
export type GanttMode='week'|'biweek'|'month'|'year';
export function monday(date:string){const d=new Date(date+'T12:00:00');return addDays(date,-((d.getDay()+6)%7))}
export function range(anchor:string,mode:GanttMode){const date=new Date(anchor+'T12:00:00'),y=date.getFullYear(),m=date.getMonth();const start=mode==='year'?fmt(new Date(y,0,1)):mode==='month'?fmt(new Date(y,m,1)):monday(anchor);const end=mode==='year'?fmt(new Date(y,11,31)):mode==='month'?fmt(new Date(y,m+1,0)):addDays(start,mode==='week'?6:13);return {start,end,length:days(start,end)+1}}
export function shift(anchor:string,mode:GanttMode,n:number){const d=new Date(anchor+'T12:00:00');return mode==='year'?fmt(new Date(d.getFullYear()+n,0,1)):mode==='month'?fmt(new Date(d.getFullYear(),d.getMonth()+n,1)):addDays(anchor,n*(mode==='week'?7:14))}
export function belongs(item:Item,id:string,all:Item[]){if(!id||id==='all')return true;let current:Item|undefined=item;const visited=new Set<string>();while(current&&!visited.has(current.id)){if(current.id===id)return true;visited.add(current.id);current=all.find(x=>x.id===current!.parent)}return false}
export function ordered(source:Item[]){const output:{item:Item;depth:number}[]=[],ids=new Set(source.map(x=>x.id));function visit(item:Item,depth:number){output.push({item,depth});source.filter(x=>x.parent===item.id).forEach(x=>visit(x,depth+1))}source.filter(x=>!x.parent||!ids.has(x.parent)).forEach(x=>visit(x,0));return output}
